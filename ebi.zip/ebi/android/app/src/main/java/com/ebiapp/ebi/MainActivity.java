package com.ebiapp.ebi;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}

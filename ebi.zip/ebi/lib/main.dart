import 'package:flutter/material.dart';
import 'package:ebi/screens/auth_page.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  WidgetsBinding widgetsBinding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: widgetsBinding);
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(
    const MaterialApp(
      color: Colors.lightBlueAccent,
      title: "EBI Instructors App",
      debugShowCheckedModeBanner: false,
      home: AuthPage(),
    ),
  );
  FlutterNativeSplash.remove();
}






import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class aboutus extends StatefulWidget{
  const aboutus({super.key});

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _aboutus();
  }

}



class _aboutus extends State<aboutus>{

  launchEBIURL(String ebiu) async{
    await launch(ebiu, forceWebView: false );
  }

  String ebiurl = "https://ebi.gov.eg/";

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      appBar: AppBar(
        title: Text("About Us"),
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors:
                [
                  Colors.blueAccent,
                  Colors.deepPurple,
                ],
                begin: FractionalOffset(0.0, 0.0),
                end: FractionalOffset(1.0, 0.0),
                stops: [ 0.0, 1.0],
                tileMode: TileMode.clamp,
              )
          ),
        ),
      ),
      body: const Padding(
        padding: EdgeInsets.all(10.0),
        child: SizedBox(
          child: Text("The Egyptian Banking Institute"
              "(EBI) was established in 1991 by the Central Bank of Egypt (CBE)"
              " to act as its official training arm with "
              "a vision to be the preferred partner "
              "for developing the human capital of the banking ecosystem in Egypt, "
              "and the lighthouse for banking sector development across "
              "strategic African and Arab countries, "
              "through mirroring the latest international banking trends."),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          launchEBIURL(ebiurl);
        },
        icon: const Icon(Icons.add),
        label: const Text("For More Details"),
        backgroundColor: Colors.lightBlueAccent,
      ),
    );
  }

}


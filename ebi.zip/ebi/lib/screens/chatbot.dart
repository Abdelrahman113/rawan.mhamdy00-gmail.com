import 'package:flutter/material.dart';


class chatBot extends StatefulWidget {
  const chatBot({super.key});

  @override
  State<chatBot> createState() => _chatBotState();
}

class _chatBotState extends State<chatBot> {
  var chatController = TextEditingController();
  var textControllerChat = 'Welcome to EBI Bot Chat';


  @override
  Widget build(BuildContext context) {
    return ebiChatBot();
  }

  Scaffold ebiChatBot(){
    return Scaffold(
      appBar: AppBar(
        title: const Text("EBI Chat"),
        backgroundColor: Colors.deepPurple[400],
      ),
      body: const SafeArea(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
            ],
          ),
        ),
      ),
      bottomSheet: Padding(
        padding: const EdgeInsets.all(10),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: chatController,
                decoration: const InputDecoration(
                  hintText: "write here...",
                  hintStyle: TextStyle(fontSize: 16.0, color: Colors.deepPurple),
                ),
              ),
            ),
            IconButton(
                onPressed: (){
                  setState(() {
                    return;
                  });},
                icon: const Icon(
                  Icons.attach_file,
                  color: Colors.deepPurple,
                )
            ),
            IconButton(
              onPressed: (){
                setState(() {
                  chatController = textControllerChat as TextEditingController;
                });
              },
              icon: const Icon(
                Icons.send,
                color: Colors.deepPurple,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

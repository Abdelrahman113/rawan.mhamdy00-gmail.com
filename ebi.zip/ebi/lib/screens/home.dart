import 'package:ebi/screens/ebitestimonals.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:ebi/screens/exams.dart';
import 'package:ebi/screens/chat.dart';
import 'package:ebi/screens/more.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import 'package:ebi/screens/library.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<StatefulWidget> createState() {
    return _HomePage();
  }
}

class _HomePage extends State<HomePage> {
  DocumentReference userFirstName = FirebaseFirestore.instance.collection('users')
      .doc(FirebaseAuth.instance.currentUser!.uid);

  void logOutIcon(){
    FirebaseAuth.instance.signOut();
  }

  int _currentNavIndex = 0;
  final PageController _pageController = PageController(initialPage: 0);

  launchURL(String urls) async {
    await launch(urls, forceWebView: false);
  }

  @override
  Widget build(BuildContext context) {
    return scaffold();
  }

  Scaffold scaffold() {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(
            gradient: LinearGradient(
                colors:
                [
                  Colors.blueAccent,
                  Colors.deepPurple,
                ],
              begin: FractionalOffset(0.0, 0.0),
              end: FractionalOffset(1.0, 0.0),
              stops: [ 0.0, 1.0],
              tileMode: TileMode.clamp,
            )
          ),
        ),
        automaticallyImplyLeading: false,
        actions: [
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () {
              logOutIcon();
            },
          ),
        ],
        title: FutureBuilder <DocumentSnapshot>(
            future: userFirstName.get(),
            builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshot) {
              if (snapshot.hasError) {
                return const Text("Something went wrong");
              }
              if (snapshot.hasData && !snapshot.data!.exists) {
                return const Text("no name entered");
              }
              if (snapshot.connectionState == ConnectionState.done) {
                Map<String, dynamic> data = snapshot.data!.data() as Map<String, dynamic>;
                return Text("Hello ${data['firstname']}");
              }
              return const Text("loading...");
            },
        )
      ),
      body: PageView(
          controller: _pageController,
          onPageChanged: (newIndexNav) {
            setState(() {
              _currentNavIndex = newIndexNav;
            });
          },
          children: <Widget>[
            homeView(),
            chat(),
            EBILibrary(),
            assessment(),
            more(),
          ]),
      bottomNavigationBar: BottomNavigationBar(
          currentIndex: _currentNavIndex,
          onTap: (IndexNav) {
            setState(() {
              _pageController.animateToPage(IndexNav,
                  duration: const Duration(milliseconds: 50), curve: Curves.ease);
            });
          },
          type: BottomNavigationBarType.shifting,
          fixedColor: Colors.blueAccent,
          showUnselectedLabels: true,
          unselectedItemColor: Colors.black,
          items: const <BottomNavigationBarItem>[
            BottomNavigationBarItem(
                icon: Icon(
                  Icons.home,
                  color: Colors.indigoAccent,
                ),
                label: "Home"),
            BottomNavigationBarItem(
              icon: Icon(Icons.chat_sharp, color: Colors.indigoAccent),
              label: "Contact",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.library_add, color: Colors.indigoAccent),
              label: "Library",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.quiz, color: Colors.indigoAccent),
              label: "Assessment",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.dashboard_customize, color: Colors.indigoAccent),
              label: "More",
            ),
          ]),
    );
  }

  ListView homeView() {
    return ListView(
      children: <Widget>[
        const SizedBox(
          height: 10,
        ),
        const Text(
          "EBI Public Courses",
          textAlign: TextAlign.center,
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                  children: <Widget>[
                courseView("images/LMS_BG_youth.jpg",
                    "Financial education for youth 2022"),
                courseView("images/LMS_BG_big.jpg",
                    "Financial education for Adults 2022"),
                courseView("images/LMS_BG_child.jpg",
                    "Financial education for child 2022"),
                courseView("images/LMS_BG.jpg",
                    "   البرنامج التعريفى عن الائتمان فى البنوك"),
              ]),
            ],
          ),
        ),
        onlineSessions(),
        ebiCatalog('images/ebicatalog.png', 'EBI Catalog'),
        const SizedBox(
          height: 20,
        ),
        Text(
          "Testimonials",
          textAlign: TextAlign.center,
        ),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                  children: <Widget>[
                    testimonials('o2NrUZ0FQug', 'أراء بعض المتدربين في شهادة المحامي المصرفي'),
                    testimonials('4d7smSdJ6lE', 'EBI Entrepreneurship Program Testimonial'),
                    testimonials('YIy_tM9Tkps', 'Future Leaders: Interview with Hussein Refai'),
                    Column(
                      children: <Widget>[
                        SizedBox(width: 120,),
                        IconButton(
                          onPressed: (){
                            Navigator.push(context, MaterialPageRoute(builder: (context){
                              return EbiTestimonials();
                            }));
                          },
                          color: Colors.blueAccent,
                          iconSize: 50,
                          icon: Icon(Icons.arrow_circle_right),
                        ),
                        Text("View All"),
                      ],
                    )
                    ]),
            ],
          ),
        ),
        const SizedBox(
          height: 70,
        ),
      ],
    );
  }

  SizedBox courseView(dynamic pImage, dynamic courseName) {
    dynamic image = pImage;
    dynamic courseName0 = courseName;
    const String eUrl = "https://lms.ebi.gov.eg/login/index.php";
    return SizedBox(
      width: 300.0,
      height: 210.0,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Container(
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: Colors.lightBlueAccent, width: 1.0),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(
                  color: Colors.blue,
                  offset: Offset(
                    2.0,
                    2.0,
                  ),
                  blurRadius: 2.0,
                  spreadRadius: 1.0,
                )
              ]),
          child: Stack(
            children: <Widget>[
              InkWell(
                onTap: () {
                  launchURL(eUrl);
                },
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  margin: const EdgeInsets.all(10),
                  child: SizedBox(
                      width: 500.0,
                      height: 150.0,
                      child: Image.asset(
                        image,
                        fit: BoxFit.fill,
                      )),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 30,
                child: SizedBox(
                  height: 40,
                  child: Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Center(
                      child: Text(
                        courseName0,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  Container onlineSessions() {
    return Container(
      child: const Expanded(
        child: Column(
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(top: 15, bottom: 8,),
              child: Text(
                "Upcoming Webinars Sessions",
                textAlign: TextAlign.center,
              ),
            ),
            ExpansionTile(
              title: Text("Banking Sessions"),
              leading: Icon(Icons.calendar_month),
              trailing: Icon(Icons.arrow_drop_down),
              subtitle: Text("Book your Slot now"),
              children: [
                ListTile(
                  title: Text("Introduction to Credit"),
                  subtitle: Text("at Friday 16/06/2023, 04:00 PM to 07:00 PM"),
                  trailing: Icon(Icons.add),
                ),
                ListTile(
                  title: Text("Introduction to Financial Inclusion"),
                  subtitle: Text("at Saturday 17/06/2023, 04:00 PM to 07:00 PM"),
                  trailing: Icon(Icons.add),
                )
              ] ,
            ),
            ExpansionTile(
              title: Text("PMD Sessions"),
              leading: Icon(Icons.calendar_month),
              trailing: Icon(Icons.arrow_drop_down),
              subtitle: Text("Book your Slot now"),
              children: [
                ListTile(
                  title: Text("Introduction to Teamwork"),
                  subtitle: Text("at Friday 16/06/2023, 04:00 PM to 07:00 PM"),
                  trailing: Icon(Icons.add),
                ),
                ListTile(
                  title: Text("Introduction to Leadership"),
                  subtitle: Text("at Saturday 17/06/2023, 04:00 PM to 07:00 PM"),
                  trailing: Icon(Icons.add),
                )
              ] ,
            ),
            ExpansionTile(
              title: Text("SME Sessions"),
              leading: Icon(Icons.calendar_month),
              trailing: Icon(Icons.arrow_drop_down),
              subtitle: Text("Book your Slot now"),
              children: [
                Text("No Sessions are available"),
              ] ,
            ),
            ExpansionTile(
              title: Text("IT Training Sessions"),
              leading: Icon(Icons.calendar_month),
              trailing: Icon(Icons.arrow_drop_down),
              subtitle: Text("Book your Slot now"),
              children: [
                Text("No Sessions are available"),
              ] ,
            ),
          ],
        ),
      ),
    );
  }

  Expanded ebiCatalog(dynamic pImage, dynamic courseName) {
    dynamic image = pImage;
    dynamic courseName0 = courseName;
    const String ebiPortTrain = "https://ebiexternalfiles.blob.core.windows.net/literacy/Training%20Catalogue-2023.pdf";
    return Expanded(
      child: SizedBox(
        width: 500.0,
        height: 420.0,
        child: Container(
          child: Stack(
            children: <Widget>[
              InkWell(
                onTap: () {
                  launch(ebiPortTrain);
                },
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  margin: const EdgeInsets.all(10),
                  child: Column(
                    children: [
                      SizedBox(
                        width: 430.0,
                        height: 350.0,
                        child: Image.asset(
                          image,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                child: Container(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 350),
                      child: Text(courseName0),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  SizedBox testimonials(dynamic vlink, dynamic vTopic) {
    dynamic videoTopic = vTopic;
    YoutubePlayerController? youTubeController;
    youTubeController = YoutubePlayerController(
      initialVideoId: vlink,
      flags: const YoutubePlayerFlags(
        autoPlay: false,
        mute: false,
        isLive: false,
        controlsVisibleAtStart: true,
        disableDragSeek: true,
      ),
    );
    return SizedBox(
      width: 300.0,
      height: 210.0,
      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: Colors.lightBlueAccent, width: 1.0),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(
                  color: Colors.blueAccent,
                  offset: Offset(
                    2.0,
                    2.0,
                  ),
                  blurRadius: 2.0,
                  spreadRadius: 1.0,
                )
              ]),
          child: Stack(
            children: <Widget>[
              YoutubePlayerBuilder(
                  player: YoutubePlayer(controller: youTubeController!,
                  ),
                  builder: (context, player){
                    return player;
                  }
              ),
              Padding(
                padding: const EdgeInsets.only(top: 155),
                child: Center(
                  child: SizedBox(
                    height: 40,
                    child: Center(
                      child: Text(videoTopic,
                      ),
                    ),
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }


}

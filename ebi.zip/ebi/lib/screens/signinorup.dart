import 'package:flutter/material.dart';
import 'package:ebi/screens/signin.dart';
import 'package:ebi/screens/signup.dart';

class SignInorUp extends StatefulWidget {
  const SignInorUp({Key? key}) : super(key: key);

  @override
  State<SignInorUp> createState() => _SignInorUpState();
}

class _SignInorUpState extends State<SignInorUp> {
  bool showLoginPage = true;

  void togglePages(){
    setState(() {
      showLoginPage = !showLoginPage;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (showLoginPage){
      return SignIn(
        onTap: togglePages,
      );
    }else{
      return SignUp(
        onTap: togglePages,
      );
    }
  }
}

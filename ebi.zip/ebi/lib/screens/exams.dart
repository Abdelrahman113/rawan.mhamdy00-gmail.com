import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class assessment extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _assessment();
  }
}

class _assessment extends State<assessment> {
  launchEBILMSURL(String ebiu) async {
    await launch(ebiu, forceWebView: false);
  }

  Expanded examView(dynamic pImage, dynamic courseName) {
    dynamic image = pImage;
    dynamic courseName0 = courseName;
    const String ebiLMSUrl = "https://lms.ebi.gov.eg/login/index.php";
    return Expanded(
      child: SizedBox(
        width: 500.0,
        height: 220.0,
        child: Container(
          child: Stack(
            children: <Widget>[
              InkWell(
                onTap: () {
                  launchEBILMSURL(ebiLMSUrl);
                },
                child: Card(
                  elevation: 5,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  margin: const EdgeInsets.all(10),
                  child: Column(
                    children: [
                      SizedBox(
                        width: 430.0,
                        height: 160.0,
                        child: Image.asset(
                          image,
                          fit: BoxFit.fill,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(
                child: Container(
                  child: Center(
                    child: Padding(
                      padding: const EdgeInsets.only(top: 160),
                      child: Text(courseName0),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: <Widget>[
        const Padding(
          padding: EdgeInsets.only(top: 20.0),
          child: Center(
            child: Text("EBI Coaching Assessments"),
          ),
        ),
        examView("images/CareerTest1.jpg", "Personality Assessment"),
        examView("images/CareerTest2.jpg", "Career Assessment"),
        examView("images/CareerTest3.jpg", "IQ Test"),
      ],
    );
  }
}

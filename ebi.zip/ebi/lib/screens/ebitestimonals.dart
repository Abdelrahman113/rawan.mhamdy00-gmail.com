import 'package:flutter/material.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';

class EbiTestimonials extends StatefulWidget {
  const EbiTestimonials({super.key});

  @override
  State<EbiTestimonials> createState() => _EbiTestimonialsState();
}

class _EbiTestimonialsState extends State<EbiTestimonials> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors:
                [
                  Colors.blueAccent,
                  Colors.deepPurple,
                ],
                begin: FractionalOffset(0.0, 0.0),
                end: FractionalOffset(1.0, 0.0),
                stops: [ 0.0, 1.0],
                tileMode: TileMode.clamp,
              )
          ),
        ),
        title: Text("Testimonials",),
        centerTitle: true,
      ),
      body: TestimonialsList(),
    );
  }

  ListView TestimonialsList() {
    return ListView(
      children: <Widget>[
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              EbiYTube('o2NrUZ0FQug'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("أراء بعض المتدربين في شهادة المحامي المصرفي",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('4d7smSdJ6lE'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI Entrepreneurship Program Testimonial",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('YIy_tM9Tkps'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("#Future Leaders: Interview with Hussein Refai",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('wopxpG6QF-8'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("#FutureLeaders: Interview with Ihab ElSewerky",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('1R8_YFZlEV8'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("African Future Leaders - Testimonials",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('HFUQlVdJvj0'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Emerging Leaders Program Testimonials",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('STPf18zSQMc'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI \"SME Junior Academy\" Program - Testimonials",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('1gZcunq3S9k'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI - African trainees testimonial - French",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('v62gwWCXrP4'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI - African trainees testimonial - English",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('wxYeAA5Vb8Q'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Egypt Future Leaders",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('wRCeafJ9ln4'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("آراء المشاركين فى برامجنا فى EBI",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('AanTrcOVvFA'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Graduate School of Banking - Partner",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('hmRKU8ef2yg'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("African Future Leaders - Testimonials",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('WjDAWrUmJjU'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI Partner \"Risk Reward\"",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('m317JVmGXc0'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("ZISHI Cornerstone our strategic partner",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('k7agb2uetMA'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI Training Experience",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('YKowaEKemwc'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Our Partner \"House of Training\"",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('89VGm5m3fwo'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI Partner - Solveworx",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('94W3ZFX9dMM'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("آراء بعض المشاركين في برنامج Professional Training of Trainers (TOT)",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              EbiYTube('rFKdzzJgvbY'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("أراء بعض من المشاركين في شهادة إخصائي معتمد في تمويل المشروعات الصغيرة والمتوسطة",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('Bq85RWrDNXA'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI Executive Program Testimonial",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('p18DsqlJa_U'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Credit Certificate Testimonial",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('gY_3csTZhHc'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Informa Testimonial",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('GHI_883ixMM'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("EBI New Distribution Channels",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('PoM-OJE7_fE'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Comprehensive Credit Testimonial",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('VzKgP46EOxA'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Game Solution",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('2QGSLOErRsM'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Banking Lawyer Testimonial",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: <Widget>[
              EbiYTube('bE6VlWYP8Dc'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("إدارة الخزينة والنقدية",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('AuB4zSLWx7c'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("Mastering Financial Statement Analysis Program - Testimonial Video",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        Card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              EbiYTube('64o8tEhwvps'),
              const SizedBox(
                height: 20,
              ),
              const Padding(padding: EdgeInsets.symmetric(horizontal: 20),
                child: SelectableText("House of Training Testimonial",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),),
              ),
              const SizedBox(
                height: 20,
              ),
            ],
          ),
        ),
        ],);
}


  SizedBox EbiYTube(dynamic vlink) {
    YoutubePlayerController? youTubeController;
    youTubeController = YoutubePlayerController(
      initialVideoId: vlink,
      flags: const YoutubePlayerFlags(
        autoPlay: false,
        mute: false,
        isLive: false,
        controlsVisibleAtStart: true,
        disableDragSeek: true,
      ),
    );
    return SizedBox(

      child: Padding(
        padding: const EdgeInsets.all(10),
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(color: Colors.lightBlueAccent, width: 1.0),
              color: Colors.white,
              boxShadow: const [
                BoxShadow(
                  color: Colors.blueAccent,
                  offset: Offset(
                    2.0,
                    2.0,
                  ),
                  blurRadius: 2.0,
                  spreadRadius: 1.0,
                )
              ]),
              child: YoutubePlayerBuilder(
                  player: YoutubePlayer(controller: youTubeController!,
                  ),
                  builder: (context, player){
                    return player;
                  }
              ),
        ),
      ),
    );
  }

}

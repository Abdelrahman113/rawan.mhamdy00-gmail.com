import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class passwordReset extends StatefulWidget {
  const passwordReset({super.key});

  @override
  State<passwordReset> createState() => _passwordResetState();
}

class _passwordResetState extends State<passwordReset> {
  TextEditingController emailController = TextEditingController();

  Future resetPasswordLink() async{
    try{
      await FirebaseAuth.instance.sendPasswordResetEmail(email: emailController.text.trim());
    }on FirebaseAuthException catch(e){
      print(e);
    }
  }

  @override
  void dispose(){
    super.dispose();
    emailController.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        flexibleSpace: Container(
          decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors:
                [
                  Colors.blueAccent,
                  Colors.purpleAccent,
                ],
                begin: FractionalOffset(0.0, 0.0),
                end: FractionalOffset(1.0, 0.0),
                stops: [ 0.0, 1.0],
                tileMode: TileMode.clamp,
              )
          ),
        ),
        title: Text("Reset your Password",),
        centerTitle: true,
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Text("Please Enter your Email to get a resetting password link",
          textAlign: TextAlign.center,
          style: TextStyle(
            fontSize: 14,
            color: Colors.grey[600]
          ),
          ),
          SizedBox(
            height: 10,
          ),
          Padding(
            padding: const EdgeInsets.all(15.0),
            child: TextFormField(
              controller: emailController,
              decoration: InputDecoration(
                enabledBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.white),
                  borderRadius: BorderRadius.circular(12),
                ),
                focusedBorder: OutlineInputBorder(
                  borderSide: BorderSide(color: Colors.deepPurple),
                  borderRadius: BorderRadius.circular(12),
                ),
                hintText: "Email",
                fillColor: Colors.grey[300],
                filled: true,
              ),
            ),
          ),
          SizedBox(height: 20,),
          MaterialButton(
              onPressed: resetPasswordLink,
            child: Text("Send Reset Pasword Link"),
            color: Colors.deepPurple[200],
          )
        ],
      ),
    );
  }
}

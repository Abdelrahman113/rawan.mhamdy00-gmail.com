// ignore_for_file: non_constant_identifier_names, prefer_interpolation_to_compose_strings

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter/cupertino.dart';
import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:ebi/animations/fadeanimation.dart';



class SignUp extends StatefulWidget{
  final Function()? onTap;
  const SignUp({super.key, required this.onTap});

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _SignUp();
  }
  
}

class _SignUp extends State<SignUp>{
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  final confirmPasswordController = TextEditingController();
  final emailController = TextEditingController();
  final firstnameController = TextEditingController();
  final lastnameController = TextEditingController();
  final nationalIDController = TextEditingController();
  final promoCodeController = TextEditingController();
  String? cityValue = "Cairo";
  static final RegExp numberRegExp = RegExp(r'[0-9]');
  //final countryController = TextEditingController();

  bool passwordConfirmed(){
    if(passwordController.text.trim() == confirmPasswordController.text.trim()){
      return true;
    }else{
      return false;
    }
  }

  Future SignUserUp() async{

    Future<bool> usernameCheck(String username) async {
      QuerySnapshot usernamesnapshot = await FirebaseFirestore.instance
          .collection('users').where("username",isEqualTo: username).get();
      bool usernameBoolCheck = usernamesnapshot.docs.isEmpty;
      return usernameBoolCheck;
    }

    Future<bool> NIDCheck(int NationalID) async {
      QuerySnapshot NIDsnapshot = await FirebaseFirestore.instance
          .collection('users').where("nationalID",isEqualTo: NationalID).get();
      bool NIDBoolCheck = NIDsnapshot.docs.isEmpty;
      return NIDBoolCheck;
    }
    if(await usernameCheck(usernameController.text.trim().toLowerCase())) {
              if (passwordConfirmed()) {
                try {
                  if (await NIDCheck(
                      int.parse(nationalIDController.text.trim()))) {
                    final credential = await FirebaseAuth.instance
                        .createUserWithEmailAndPassword(
                        email: emailController.text.trim(),
                        password: passwordController.text.trim()
                    );
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        backgroundColor: Colors.greenAccent,
                        content: Text('Account Successfully Created!',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                              color: Colors.black
                          ),),
                      ),
                    );
                    String userID = credential.user!.uid;
                    await FirebaseFirestore.instance.collection('users')
                        .doc(userID)
                        .set({
                      "uid": userID,
                      "username": usernameController.text.trim().toLowerCase(),
                      "email": emailController.text.trim(),
                      "firstname": firstnameController.text.trim(),
                      "lastname": lastnameController.text.trim(),
                      "nationalID": int.parse(nationalIDController.text.trim()),
                      "promoCode": promoCodeController.text.trim(),
                      "city": cityValue,
                      "country": "Egypt",
                      "role": "authenticated_user"
                    });
                  } else {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        backgroundColor: Colors.red,
                        content: Text('National ID already exist!',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                      ),
                    );
                  }
                } on FirebaseAuthException catch (e) {
                  if (e.code == "email-already-in-use") {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        backgroundColor: Colors.red,
                        content: Text('Email already exist!',
                          textAlign: TextAlign.center,
                          style: TextStyle(
                            color: Colors.black,
                          ),
                        ),
                      ),
                    );
                  } else {
                    print("the error is $e");
                  }
                }
              } else {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    backgroundColor: Colors.red,
                    content: Text('Confirmation Password is Different',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        color: Colors.black,
                      ),
                    ),
                  ),
                );
              }
    }else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.red,
          content: Text('Username already exist!',
            textAlign: TextAlign.center,
            style: TextStyle(
              color: Colors.black,
            ),
          ),
        ),
      );
    }

  }


  @override
  void dispose(){
    usernameController.dispose();
    emailController.dispose();
    passwordController.dispose();
    confirmPasswordController.dispose();
    firstnameController.dispose();
    lastnameController.dispose();
    nationalIDController.dispose();
    promoCodeController.dispose();
    super.dispose();
  }

  var ebiLogo = "images/ebilog.png";
  bool PassIn = false;
  bool confPassIn = false;
  final List<String> Cities = [
    "Cairo",
    "Alexandria",
    "Gizeh",
    "Shubra El-Kheima",
    "Port Said",
    "Suez",
    "Luxor",
    "al-Mansura",
    "El-Mahalla El-Kubra",
    "Tanta",
    "Asyut",
    "Ismailia",
    "Fayyum",
    "Zagazig",
    "Aswan",
    "Damietta",
    "Damanhur",
    "al-Minya",
    "Beni Suef",
    "Qena",
    "Sohag",
    "Hurghada",
    "6th of October City",
    "Shibin El Kom",
    "Banha",
    "Kafr el-Sheikh",
    "Arish",
    "Mallawi",
    "10th of Ramadan City",
    "Bilbais",
    "Marsa Matruh",
    "Idfu",
    "Mit Ghamr",
    "Al-Hamidiyya",
    "Desouk",
    "Qalyub",
    "Abu Kabir",
    "Kafr el-Dawwar",
    "Girga",
    "Akhmim",
    "Matareya",

  ];

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SignUpPage();
  }

  Scaffold SignUpPage() {
    return Scaffold(
      body: ListView(children: <Widget>[
        ClipPath(
          clipper: WaveClipperTwo(),
          child: FadeAnimation(0.6,Container(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors:
                  [
                    Colors.blueAccent,
                    Colors.deepPurple,
                  ],
                  begin: FractionalOffset(0.0, 0.0),
                  end: FractionalOffset(1.0, 0.0),
                  stops: [ 0.0, 1.0],
                  tileMode: TileMode.clamp,
                )
            ),
            height: 140,
            child: Padding(
              padding: const EdgeInsets.only(bottom: 25),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    width: 90,
                    height: 100,
                    child: FadeAnimation(1.3,Image.asset(ebiLogo)),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  FadeAnimation(1.3, const Text(
                    "Create New Account",
                    style: TextStyle(
                      fontSize: 26,
                    ),
                  ),)
                ],
              ),
            ),
          ),),
        ),
        const SizedBox(
          height: 40,
        ),

        SignUpForm(),
      ]),
    );
  }

  TextSpan requiredField(){
    return const TextSpan(
              text: " * ",
              style: TextStyle(
                  fontSize: 15,
                  color: Colors.red
              ),
            );
  }

  SafeArea SignUpForm(){
    return SafeArea(
          child: Form(
            key: _formKey,
          child: Padding(
            padding: const EdgeInsets.only(left: 20, right: 20),
            child: FadeAnimation(2.5, Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  FadeAnimation(2.9, CupertinoFormSection.insetGrouped(
                    header: const Text("Login Info.",
                      style: TextStyle(
                          fontSize: 16,
                          color: Colors.blueAccent
                      ),),
                    children: <Widget>[
                      Padding(padding: const EdgeInsets.all(10),
                        child: TextFormField(
                          controller: usernameController,
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter your username';
                            }if (value.length > 20){
                              return 'Please enter less than 20 characters';
                            }
                            return null;
                          },
                          decoration: InputDecoration(
                              label: RichText(
                                text: TextSpan(
                                    children: [
                                      TextSpan(
                                        text: "Username:",
                                        style: TextStyle(
                                            fontSize: 14,
                                            color: Colors.grey[600]
                                        ),
                                      ),
                                      requiredField(),
                                    ]
                                ),
                              ),
                              border: InputBorder.none,
                              icon: const Icon(Icons.person),
                              hintStyle: const TextStyle(fontSize: 16.0, color: Colors.blueAccent)
                          ),
                        ),
                      ),

                      Padding(padding: const EdgeInsets.all(10),
                        child: TextFormField(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter the password';
                            }if (value.length > 20 || value.length < 8){
                              return 'Please enter between 8 to 20 characters';
                            }if (!value.contains(RegExp(r'[A-Z]'))) {
                              return 'Password does\'t contain Capital letter';
                            }if (!value.contains(RegExp(r'[a-z]'))) {
                              return 'Password does\'t contain Small letter';
                            }if (!value.contains(RegExp(r'[0-9]'))) {
                              return 'Password does\'t contain any number';
                            }if (!value.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]'))) {
                              return 'Password does\'t contain Special char';
                            }
                            return null;
                          },
                          controller: passwordController,
                          obscureText: !PassIn,
                          decoration: InputDecoration(
                            label: RichText(
                              text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "Password:",
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey[600]
                                      ),
                                    ),
                                    requiredField(),
                                  ]
                              ),
                            ),
                            border: InputBorder.none,
                            icon: const Icon(Icons.lock),
                            fillColor: Colors.black,
                            hintStyle: const TextStyle(fontSize: 16.0, color: Colors.blueAccent),
                            suffixIcon: IconButton(
                                onPressed: (){
                                  setState(() {
                                    PassIn = !PassIn;
                                  });
                                },
                                icon: Icon(PassIn ? Icons.visibility : Icons.visibility_off,
                                  color: Theme.of(context).primaryColorDark,)
                            ),
                          ),

                        ),
                      ),
                      Padding(padding: const EdgeInsets.all(10),
                        child: TextFormField(
                          validator: (value) {
                            if (value == null || value.isEmpty) {
                              return 'Please enter the confirmation password';
                            }if (value.length > 20 || value.length < 8){
                              return 'Please enter between 8 to 20 characters';
                            }
                            return null;
                          },
                          controller: confirmPasswordController,
                          obscureText: !confPassIn,
                          decoration: InputDecoration(
                            label: RichText(
                              text: TextSpan(
                                  children: [
                                    TextSpan(
                                      text: "Confirm Password:",
                                      style: TextStyle(
                                          fontSize: 14,
                                          color: Colors.grey[600]
                                      ),
                                    ),
                                    requiredField(),
                                  ]
                              ),
                            ),
                            border: InputBorder.none,
                            icon: const Icon(Icons.lock),
                            fillColor: Colors.black,
                            hintStyle: const TextStyle(fontSize: 16.0, color: Colors.blueAccent),
                            suffixIcon: IconButton(
                                onPressed: (){
                                  setState(() {
                                    confPassIn = !confPassIn;
                                  });
                                },
                                icon: Icon(confPassIn ? Icons.visibility : Icons.visibility_off,
                                  color: Theme.of(context).primaryColorDark,)
                            ),
                          ),

                        ),
                      ),
                      const Padding(padding: EdgeInsets.all(20),
                        child: Text("password must have at least 8 characters,"
                            " at least 1 digit(s), at least 1 lower case letter(s),"
                            " at least 1 upper case letter(s),"
                            " at least 1 special character(s)"
                            " such as as *, -, or #"),),
                    ],)),
                  FadeAnimation(2.9, CupertinoFormSection.insetGrouped(
                    header: const Text("Details",
                      style: TextStyle(
                        fontSize: 16,
                      ),),
                    children: <Widget>[
                      CupertinoTextFormFieldRow(
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your email';
                          }if (value.length > 100){
                            return 'Please enter less than 100';
                          }
                          return null;
                        },
                        style: const TextStyle(fontSize: 12),
                        controller: emailController,
                        prefix: RichText(
                          text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Email Address:",
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey[600]
                                  ),
                                ),
                                requiredField(),
                              ]
                          ),
                        ),
                        placeholder: "Enter your email",
                      ),
                      CupertinoTextFormFieldRow(
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your First Name';
                          }if (value.length > 50){
                            return 'Please enter less than 50 characters';
                          }
                          return null;
                        },
                        style: const TextStyle(fontSize: 12),
                        controller: firstnameController,
                        prefix: RichText(
                          text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "First Name:",
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey[600]
                                  ),
                                ),
                                requiredField(),
                              ]
                          ),
                        ),
                        placeholder: "Enter your first name",
                      ),
                      CupertinoTextFormFieldRow(
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your Last Name';
                          }if (value.length > 50){
                            return 'Please enter less than 50 characters';
                          }
                          return null;
                        },
                        style: const TextStyle(fontSize: 12),
                        controller: lastnameController,
                        prefix: RichText(
                          text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "Last Name:",
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey[600]
                                  ),
                                ),
                                requiredField(),
                              ]
                          ),
                        ),
                        placeholder: "Enter your last name",
                      ),
                      CupertinoTextFormFieldRow(
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter your National ID';
                          }if(value.contains(RegExp(r'[!@#$%^&*(),.?":{}|<>]')) || value.contains(RegExp(r'[a-z]'))
                              || value.contains(RegExp(r'[A-Z]'))){
                            return 'Please enter a number';
                          }if (value.length < 14 || value.length > 14){
                            return 'Please enter a valid NID with 14 digits';
                          }
                          return null;
                        },
                        style: const TextStyle(fontSize: 12),
                        controller: nationalIDController,
                        prefix: RichText(
                          text: TextSpan(
                              children: [
                                TextSpan(
                                  text: "National ID:",
                                  style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey[600]
                                  ),
                                ),
                                requiredField(),
                              ]
                          ),
                        ),
                        placeholder: "Enter your national ID",
                      ),
                      CupertinoTextFormFieldRow(
                        style: const TextStyle(fontSize: 12),
                        controller: promoCodeController,
                        prefix: Text("Promo Code:",
                          style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600]
                          ),),
                      ),

                      DropdownButtonFormField2(
                        value: cityValue,
                        decoration: const InputDecoration(
                            isDense: true,
                            contentPadding: EdgeInsets.only(top: 5, left: 0),
                            border: InputBorder.none,
                            icon: Padding(
                              padding: EdgeInsets.only(left: 40.0),
                              child: Icon(Icons.location_city),
                            )
                        ),
                        isExpanded: true,
                        items: Cities.map((item) => DropdownMenuItem<String>(
                          value: item,
                          child: Text(
                            item,
                            style: const TextStyle(
                              fontSize: 12,
                            ),
                          ),
                        ))
                            .toList(),
                        validator: (value) {
                          if (value == null) {
                            return 'Please Select a City.';
                          }
                          return null;
                        },
                        onChanged: (value) {
                          setState(() {
                            cityValue = value.toString();
                          });
                        },
                        onSaved: (value) {
                          cityValue = value.toString();
                        },
                        buttonStyleData: const ButtonStyleData(
                          height: 60,
                          padding: EdgeInsets.only(left: 20, right: 10),
                        ),
                        iconStyleData: const IconStyleData(
                          icon: Icon(
                            Icons.arrow_drop_down,
                            color: Colors.black45,
                          ),
                          iconSize: 30,
                        ),
                        dropdownStyleData: DropdownStyleData(
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                      ),
                      CupertinoTextFormFieldRow(
                        prefix: Text("Country:",
                          style: TextStyle(
                              fontSize: 12,
                              color: Colors.grey[600]
                          ),),
                        readOnly: true,
                        style: const TextStyle(fontSize: 12),
                        initialValue: "Egypt",
                      ),
                    ],
                  )),
                  const SizedBox(
                    height: 20,
                  ),
                  FadeAnimation(2.9, Container(
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          width: 3
                      ),
                      color: Colors.blueGrey,
                    ),
                    child: TextButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              duration: Duration(seconds: 1, milliseconds: 100),
                              content: Text('Processing Data...',
                                textAlign: TextAlign.center,
                              ),
                            ),
                          );
                          SignUserUp();

                        }
                      },
                      child: const Text("Sign Up",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  )),

                  const SizedBox(
                    height: 40,
                  ),
                  FadeAnimation(2.9, Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      const Text("already have an account?  "),
                      GestureDetector(
                        onTap: widget.onTap,
                        child: const Text("Login now",
                          style: TextStyle(
                            color: Colors.blueAccent,
                            fontSize: 16,
                          ),),
                      ),
                    ],
                  )),
                  const SizedBox(
                    height: 15,
                  )
                ],
              ),
            )),
            ),
          ),
        );
  }


}



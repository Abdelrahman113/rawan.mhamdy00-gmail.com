import 'package:ebi/screens/chatbot.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class chat extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _chat();
  }
}

class _chat extends State<chat> {
  var chatController = TextEditingController();
  var textControllerChat = 'Welcome to EBI Bot Chat';
  var whatsappUrl ="https://wa.me/+201005094907";
  var phoneCall =  "15200";
  var facebookLink = "https://web.facebook.com/EgyptianBankingInstitute";
  var ebiMail = "mailto:contactus@ebi.gov.eg";


  Container gridViewCon(){
    return Container(
      child: Padding(
        padding: const EdgeInsets.only(top:20,),
        child: Column(
          children: <Widget>[
            GridTile(child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  height: 90,
                  width: 90,
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(50),
                      color: Colors.lightBlueAccent
                    ),
                    child: ClipOval(
                      child: Material(
                        color: Colors.blueAccent, // button color
                        child: InkWell(
                          splashColor: Colors.purple, // splash color
                          onTap: () {
                            launch(whatsappUrl);
                          }, // button pressed
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.perm_phone_msg_outlined), // icon
                              Text("WhatsApp"), // text
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 60,
                ),
                SizedBox(
                  height: 90,
                  width: 90,
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.lightBlueAccent
                    ),
                    child: ClipOval(
                      child: Material(
                        color: Colors.blueAccent, // button color
                        child: InkWell(
                          splashColor: Colors.purple, // splash color
                          onTap: () {
                            launch("tel://$phoneCall");
                          }, // button pressed
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.call), // icon
                              Text("Hotline"), // text
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],),
            ),
            const SizedBox(
              height: 30,
            ),
            GridTile(child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                SizedBox(
                  height: 90,
                  width: 90,
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.lightBlueAccent
                    ),
                    child: ClipOval(
                      child: Material(
                        color: Colors.blueAccent, // button color
                        child: InkWell(
                          splashColor: Colors.purple, // splash color
                          onTap: () {
                            launch(facebookLink);
                          }, // button pressed
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.facebook_rounded), // icon
                              Text("Facebook"), // text
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(
                  width: 60,
                ),
                SizedBox(
                  height: 90,
                  width: 90,
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(50),
                        color: Colors.lightBlueAccent
                    ),
                    child: ClipOval(
                      child: Material(
                        color: Colors.blueAccent, // button color
                        child: InkWell(
                          splashColor: Colors.purple, // splash color
                          onTap: () {
                            launch(ebiMail);
                          }, // button pressed
                          child: const Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: <Widget>[
                              Icon(Icons.mail), // icon
                              Text("Mail"), // text
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ],),
            ),
            const SizedBox(
              height: 50,
            )
          ],
        ),
      )
    );
  }

  Scaffold ebiContactUs(){
    return Scaffold(
      body:SafeArea(
        child: Padding(
          padding: EdgeInsets.all(10),
          child: Column(
            children: <Widget>[
              gridViewCon(),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () {
          Navigator.push(context, MaterialPageRoute(builder: (context){
            return chatBot();
          }));
        },
        icon: const Icon(Icons.chat_outlined),
        label: const Text("EBI Chat"),
        backgroundColor: Colors.deepPurple[400],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build

    return ebiContactUs();
  }
}

import 'package:flutter/material.dart';

class EBILibrary extends StatefulWidget {
  const EBILibrary({super.key});

  @override
  State<EBILibrary> createState() => _EBILibraryState();
}

class _EBILibraryState extends State<EBILibrary> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}

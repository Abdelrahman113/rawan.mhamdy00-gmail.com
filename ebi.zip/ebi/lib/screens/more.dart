import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_profile_picture/flutter_profile_picture.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:ebi/screens/aboutus.dart';

class more extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _more();
  }
}

class _more extends State<more>{

  DocumentReference userFullName = FirebaseFirestore.instance.collection('users')
      .doc(FirebaseAuth.instance.currentUser!.uid);
  var ebiURLReport = "https://ebi.gov.eg/contact-us-2/";

  String profileFullName = '';

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    if (profileFullName != null) {
      return FutureBuilder <DocumentSnapshot>(
        future: userFullName.get(),
        builder: (BuildContext context, AsyncSnapshot<DocumentSnapshot> snapshotfull) {
          if (snapshotfull.hasError) {
            return const Text("Something went wrong");
          }
          if (snapshotfull.hasData && !snapshotfull.data!.exists) {
            return moreTiles();
          }
          if (snapshotfull.connectionState == ConnectionState.done) {
            Map<String, dynamic> data = snapshotfull.data!.data() as Map<String, dynamic>;
            profileFullName = "${data['firstname']+' '+data['lastname']}";
            return moreTiles();
          }
          return moreTiles();
        },
      );
    }else{
      return Text("Something Went Wrong!");
    }
    
  }

  ListView moreTiles() {
    return ListView(
      children: <Widget>[
        Card(
          color: Colors.white70,
          child: Padding(padding: EdgeInsets.all(9),
          child: Row(
            children: <Widget>[
              ProfilePicture(
                name: profileFullName,
                radius: 30,
                fontsize: 20,
                tooltip: true,
              ),
              SizedBox(width: 15,),
              Text(profileFullName),
              Expanded(
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Container(
                    child: IconButton(
                      onPressed: (){
                          FirebaseAuth.instance.signOut();
                        },
                      icon:
                      Icon(Icons.logout),
                      tooltip: "Logout",
                    ),
                  )
              ),
              ),
            ],
          ),)
        ),
        ListTile(
          title: Text("About Us"),
          leading: Icon(Icons.info),
          onTap: (){
            Navigator.push(context, MaterialPageRoute(builder: (context){
              return aboutus();
            }));
          },
        ),
        ListTile(
          title: Text("Report an Issue"),
          leading: Icon(Icons.report_problem_outlined),
          onTap: (){
            launch(ebiURLReport);
          },
        ),


      ],
    );
  }
}

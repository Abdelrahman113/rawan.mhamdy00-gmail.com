import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:ebi/screens/passwordreset.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_custom_clippers/flutter_custom_clippers.dart';
import 'package:flutter/material.dart';
import 'package:ebi/animations/fadeanimation.dart';

class SignIn extends StatefulWidget {
  final Function()? onTap;
  const SignIn({super.key, required this.onTap});

  @override
  State<StatefulWidget> createState() {
    // TODO: implement createState
    return _SignIn();
  }
}

class _SignIn extends State<SignIn> {

  TextEditingController emailController = new TextEditingController();
  TextEditingController passwordController = new TextEditingController();
  TextEditingController usernameController = new TextEditingController();


  void wrongEmailOrPassword(){
    showDialog(
        context: context,
        builder: (context){
          return const AlertDialog(
            title: Text("Wrong Email or Password Entered"),
          );
        },
    );
  }
  void signInUser() async {
    showDialog(
        context: context,
        builder: (context){
          return const Center(
            child: CircularProgressIndicator(),
          );
        },
    );
    try {
      QuerySnapshot querysnap = await FirebaseFirestore.instance.collection('users')
      .where("username", isEqualTo: usernameController.text.trim().toLowerCase()).get();
      FirebaseAuth.instance.signInWithEmailAndPassword(
          email: querysnap.docs[0]['email'],
          password: passwordController.text.trim());
     // ignore: use_build_context_synchronously
     Navigator.pop(context);
    } on FirebaseAuthException catch(e){
      Navigator.pop(context);
      if(e.code == 'user-not-found' || e.code == 'wrong-password'){
        wrongEmailOrPassword();
      }else {
        print(e.code);
      }
    }
  }

  var ebiLogo = "images/ebilog.png";
  bool _passwordVisible = false;
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return SignInPage();
  }

  Scaffold SignInPage() {
    return Scaffold(
      body: ListView(children: <Widget>[
        ClipPath(
          clipper: WaveClipperTwo(),
          child: FadeAnimation(1,Container(
            decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors:
                  [
                    Colors.blueAccent,
                    Colors.deepPurple,
                  ],
                  begin: FractionalOffset(0.0, 0.0),
                  end: FractionalOffset(1.0, 0.0),
                  stops: [ 0.0, 1.0],
                  tileMode: TileMode.clamp,
                )
            ),
            height: 140,
            child: Padding(
              padding: EdgeInsets.only(bottom: 25),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  FadeAnimation(2, SizedBox(
                    width: 90,
                    height: 100,
                    child: Image.asset(ebiLogo),
                  ),),
                  const SizedBox(
                    width: 10,
                  ),
                  FadeAnimation(2, const SelectableText(
                    "Hello EBI Candidate",
                    style: TextStyle(
                      fontSize: 26,
                    ),)
                  ),
                ],
              ),
            ),
          ),
        ),
        ),
        const SizedBox(
          height: 20,
        ),
        loginBox(),
      ]),
    );
  }

  Center loginBox(){
    return Center(
      child: Padding(
            padding: const EdgeInsets.only(top: 2),
            child: FadeAnimation(3,Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                border: Border.all(color: Colors.lightBlueAccent, width: 1.0),
                color: Colors.grey[300],
                boxShadow: const [
                  BoxShadow(
                    color: Colors.lightBlueAccent,
                    offset: Offset(
                      2.0,
                      2.0,
                    ),
                    blurRadius: 2.0,
                    spreadRadius: 1.0,
                  )
                ],
              ),
              child: Form(
                child: SizedBox(
                height: 470,
                width: 330,
                child: Column(mainAxisAlignment: MainAxisAlignment.center,children: <Widget>[
                  // username field
                  SizedBox(
                    child: Padding(
                    padding: EdgeInsets.symmetric(horizontal: 40.0),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Align(
                          alignment: Alignment.centerRight,
                          child: SizedBox(
                            width: 250,
                            child: FadeAnimation(3.3,TextFormField(
                              controller: usernameController,
                              decoration: InputDecoration(
                                  enabledBorder: const OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                  ),
                                  focusedBorder: const OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.lightBlueAccent),
                                  ),
                                  labelText: "Username",
                                  labelStyle: TextStyle(
                                      color: Colors.grey[700]
                                  ),
                                  icon: const Icon(Icons.person),
                                  hintStyle: const TextStyle(fontSize: 16.0, color: Colors.blueAccent)
                              ),
                            ),
                            ),
                          ),
                        ),

                      ],
                    ),
                    ),
                  ),
                  // password field
                  SizedBox(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 40.0, vertical: 20),
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: <Widget>[
                          Align(
                            alignment: Alignment.center,
                            child: SizedBox(
                              width: 250,
                              child: FadeAnimation(3.6,TextFormField(
                                controller: passwordController,
                                obscureText: !_passwordVisible,
                                decoration: InputDecoration(
                                  enabledBorder: const OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.white),
                                  ),
                                  focusedBorder: const OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.lightBlueAccent),
                                  ),
                                  labelText: "Password",
                                  labelStyle: TextStyle(
                                    color: Colors.grey[700]
                                  ),
                                  icon: const Icon(Icons.lock),
                                  fillColor: Colors.black,
                                  hintStyle: const TextStyle(fontSize: 16.0, color: Colors.blueAccent),
                                  suffixIcon: IconButton(
                                      onPressed: (){
                                        setState(() {
                                          _passwordVisible = !_passwordVisible;
                                        });
                                      },
                                      icon: Icon(_passwordVisible ? Icons.visibility : Icons.visibility_off,
                                      color: Theme.of(context).primaryColorDark,)
                                  ),
                                ),

                              )),
                            ),
                          ),

                        ],
                      ),
                    ),
                  ),
                  Padding(padding: const EdgeInsets.symmetric(horizontal: 40),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: <Widget>[
                      FadeAnimation(3.9, GestureDetector(
                        onTap: (){
                          Navigator.push(context, MaterialPageRoute(builder: (context){
                            return passwordReset();
                          }
                          )
                          );
                        },
                        child: const Text("Forget Password?",
                          style: TextStyle(
                            color: Colors.blueAccent,
                            fontSize: 14,
                          ),),
                      )),

                    ],
                  ),
                  ),

                  const SizedBox(
                    height: 30,
                  ),
                  FadeAnimation(4.2, Container(
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                          width: 3
                      ),
                      color: Colors.blueGrey,
                    ),
                    child: TextButton(
                      onPressed: () {

                        signInUser();
                      },
                      child: const Text("Login",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                        ),
                      ),
                    ),
                  )),
                  const SizedBox(
                    height: 150,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.end,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      FadeAnimation(4.5, Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text("Don't have an account? "),
                          const SizedBox(
                            width: 3,
                          ),
                          GestureDetector(
                            onTap: widget.onTap,
                            child: const Text("Sign Up Now",
                              style: TextStyle(
                                color: Colors.blueAccent,
                                fontSize: 16,
                              ),),
                          ),
                        ],
                      )),
                    ],
                  )
                ],
                ),
              ),
              ),
          ),),
      ),
    );
  }

}
